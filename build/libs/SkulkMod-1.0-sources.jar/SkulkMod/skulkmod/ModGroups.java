package SkulkMod.skulkmod;

import SkulkMod.skulkmod.item.ModItems;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModGroups {

    // Ключ для вкладки (нужен для регистрации и событий)
    public static final class_5321<class_1761> SCULK_ITEM_GROUP_KEY = class_5321.method_29179(
            class_7924.field_44688,
            class_2960.method_60655(Skulkmod.MOD_ID, "sculk_items")
    );

    // Создание вкладки
    public static final class_1761 SCULK_ITEM_GROUP = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModItems.SCULK_ELYTRA)) // Иконка вкладки
            .method_47321(class_2561.method_43471("itemGroup.skulkmod")) // Название (перевод)
            .method_47324();

    // Метод для регистрации
    public static void registerItemGroups() {
        // Регистрируем вкладку в реестре
        class_2378.method_39197(class_7923.field_44687, SCULK_ITEM_GROUP_KEY, SCULK_ITEM_GROUP);

        // Добавляем предметы во вкладку
        ItemGroupEvents.modifyEntriesEvent(SCULK_ITEM_GROUP_KEY).register(itemGroup -> {
            // Твои скалк-предметы
            itemGroup.method_45421(ModItems.SCULK_PICKAXE);
            itemGroup.method_45421(ModItems.SCULK_AXE);
            itemGroup.method_45421(ModItems.SCULK_HOE);
            itemGroup.method_45421(ModItems.SCULK_SPEAR);
            itemGroup.method_45421(ModItems.SCULK_SWORD);
            itemGroup.method_45421(ModItems.SCULK_SHOVEL);
            itemGroup.method_45421(ModItems.SCULK_HORSE_ARMOR);
            itemGroup.method_45421(ModItems.SCULK_NAUTILUS_ARMOR);
            itemGroup.method_45421(ModItems.SCULK_BREAD);
            itemGroup.method_45421(ModItems.SCULK_ELYTRA);
            itemGroup.method_45421(ModItems.SCULK_SHIELD);
            itemGroup.method_45421(ModItems.SCULK_HELMET);
            itemGroup.method_45421(ModItems.SCULK_LEGGINGS);
            itemGroup.method_45421(ModItems.SCULK_CHESTPLATE);
            itemGroup.method_45421(ModItems.SCULK_BOOTS);
            itemGroup.method_45421(ModItems.SCULK_TEMPLATE);
        });
    }
}
