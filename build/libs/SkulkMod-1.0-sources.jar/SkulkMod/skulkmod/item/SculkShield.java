package SkulkMod.skulkmod.item;

import SkulkMod.skulkmod.Skulkmod;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_10707;
import net.minecraft.class_1792;
import net.minecraft.class_3417;
import net.minecraft.class_8103;
import net.minecraft.class_9307;
import net.minecraft.class_9334;

public class SculkShield extends class_1792 {

    public static final String MOD_ID = "skulkmod";

    public SculkShield(class_1793 settings) {
        super(settings.method_57349(class_9334.field_49619, class_9307.field_49404)
                .method_57349(class_9334.field_56396,
                        new class_10707(
                                0.25F, // задержка перед блоком
                                1.0F,  // множитель кулдауна
                                List.of(
                                        new class_10707.class_10708(
                                                90.0F,
                                                Optional.empty(),
                                                0.0F,
                                                1.0F
                                        )
                                ),
                                new class_10707.class_10709(
                                        3.0F,   // урон по щиту
                                        1.0F,
                                        1.0F
                                ),
                                Optional.of(class_8103.field_56242),
                                Optional.of(class_3417.field_15150),
                                Optional.of(class_3417.field_15239)
                        )
                )
                .method_57349(class_9334.field_56399, class_3417.field_15239)
        );
    }
}