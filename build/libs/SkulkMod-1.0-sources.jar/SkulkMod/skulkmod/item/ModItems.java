package SkulkMod.skulkmod.item;

import SkulkMod.skulkmod.Skulkmod;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.item.v1.FabricItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_10192;
import net.minecraft.class_10394;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1802;
import net.minecraft.class_1814;
import net.minecraft.class_1821;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3902;
import net.minecraft.class_4174;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8051;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.component.type.*;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import oshi.jna.platform.mac.SystemB;

import java.util.function.Consumer;
import java.util.function.Function;

import static net.minecraft.class_1802.field_8614;

public class ModItems {
    public static final class_1792 SCULK_TEMPLATE = registerItem("sculk_template", class_1792::new);
    public static final class_1792 SCULK_PICKAXE = registerItem("sculk_pickaxe",
            setting -> new class_1792(setting.method_66330(ModMaterials.SCULK, 4, -2.5f)));
    public static final class_1792 SCULK_BREAD = registerItem("sculk_bread", settings -> new class_1792(settings.method_19265(
            new class_4174(7, 0.6f, false ))));

    public static final class_1792 SCULK_SWORD = registerItem("sculk_sword",
            setting -> new class_1792(setting.method_66333(ModMaterials.SCULK, 6, -2.0f)));

    public static final class_1792 SCULK_SPEAR = registerItem("sculk_spear",
            setting -> new class_1792(setting.method_75216(ModMaterials.SCULK, 1.0F, 3.0F,
                    0.15F, 1.2F, 1.5F,
                    0.8F, 1.5F, 1.8F,
                    1.2F)));

    public static final class_1792 SCULK_SHOVEL = registerItem("sculk_shovel",
            setting -> new class_1821(ModMaterials.SCULK, 3.5f, -2.8f, setting));

    public static final class_1792 SCULK_AXE = registerItem("sculk_axe",
            setting -> new class_1743(ModMaterials.SCULK, 8, -2.8f, setting));

    public static final class_1792 SCULK_HOE = registerItem("sculk_hoe",
            setting -> new class_1794(ModMaterials.SCULK, -1, 2f, setting));

    public static final class_1792 SCULK_HELMET = registerItem("sculk_helmet",
            setting -> new class_1792(setting.method_66332(ModMaterials.SCULK_ARMOR, class_8051.field_41934)));
    public static final class_1792 SCULK_CHESTPLATE = registerItem("sculk_chestplate",
            setting -> new class_1792(setting.method_66332(ModMaterials.SCULK_ARMOR, class_8051.field_41935)));
    public static final class_1792 SCULK_LEGGINGS = registerItem("sculk_leggings",
            setting -> new class_1792(setting.method_66332(ModMaterials.SCULK_ARMOR, class_8051.field_41936)));
    public static final class_1792 SCULK_BOOTS = registerItem("sculk_boots",
            setting -> new class_1792(setting.method_66332(ModMaterials.SCULK_ARMOR, class_8051.field_41937)));

    public static final class_1792 SCULK_HORSE_ARMOR = registerItem("sculk_horse_armor",
            setting -> new class_1792(setting.method_67191(ModMaterials.SCULK_ANIMAL_ARMOR)));
    public static final class_1792 SCULK_NAUTILUS_ARMOR = registerItem("sculk_nautilus_armor",
            setting -> new class_1792(setting.method_75217(ModMaterials.SCULK_ANIMAL_ARMOR)));

    public static final class_1792 SCULK_ELYTRA = register("sculk_elytra", new class_1792 (new class_1792.class_1793()
                    .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Skulkmod.MOD_ID, "sculk_elytra")))
                    .method_7895(600)
                    .method_24359()
                    .method_7894(class_1814.field_8904)
                    .method_57349(class_9334.field_54197, class_3902.field_17274)
                    .method_57349(
                            class_9334.field_54196,
                            class_10192.method_64202(class_1304.field_6174)
                                    .method_64204(registerModel("sculk_elytra"))
                                    .method_64210(false).method_64203()
                    )
                    .method_61648(field_8614)
                    .method_57348(
                            class_9285.method_57480()
                                    .method_57487(
                                    class_5134.field_23718,
                                    new class_1322(class_2960.method_60655(Skulkmod.MOD_ID, "elytra.amor"),
                                            0.1F, class_1322.class_1323.field_6328), class_9274.field_49222)
                                    .method_57487(
                                            class_5134.field_23719,
                                            new class_1322(
                                                    class_2960.method_60655("sculkelytra", "flight_speed"),
                                                    0.3F,
                                                    class_1322.class_1323.field_6330
                                            ),
                                            class_9274.field_49222
                                    )
                                    .method_57486()

                    )
            )
    );



    static class_5321<class_10394> registerModel(String name) {
        return class_5321.method_29179(class_5321.method_29180(class_2960.method_60656("equipment_asset")), class_2960.method_60655(Skulkmod.MOD_ID, name));
    }
    private static class_1792 register(String name, class_1792 item) {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> entries.addAfter(class_1802.field_8833, ModItems.SCULK_ELYTRA));
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Skulkmod.MOD_ID, name), item);
    }



    public static final class_1792 SCULK_SHIELD = register("sculk_shield");

    private static class_1792 register(String name) {

        class_2960 id = class_2960.method_60655(Skulkmod.MOD_ID, name);

        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);

        class_1792.class_1793 settings = new class_1792.class_1793()
                .method_63686(key)
                .method_7895(500);
        class_1792 item = new SculkShield(settings);

        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> function) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Skulkmod.MOD_ID, name),
                function.apply(new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Skulkmod.MOD_ID, name)))));
    }

    public static void registerModItems (){
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries ->{
            entries.method_45421(SCULK_TEMPLATE);
        });
    }

}
