package SkulkMod.skulkmod.item;

import SkulkMod.skulkmod.Skulkmod;
import com.google.common.collect.Maps;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_10394;
import net.minecraft.class_1741;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3481;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_8051;
import net.minecraft.class_9886;

import static net.minecraft.class_10191.method_65368;


public class ModMaterials {
    public static final class_9886 SCULK = new class_9886(
            class_3481.field_49925,
            2200,   // durability
            11.0F,   // mining speed
            3.0F,   // attack damage
            15,     // enchantability
            class_6862.method_40092(
                    class_7923.field_41178.method_46765(),
                    class_2960.method_60655(Skulkmod.MOD_ID, "skulk_repair")
            )
    );
    class_5321<? extends class_2378<class_10394>> REGISTRY_KEY = class_5321.method_29180(class_2960.method_60656("equipment_asset"));
 private final static class_5321<class_10394> NOTHING = method_65368("sculk");

    public static final class_1741 SCULK_ARMOR = new class_1741(60, createDefenseMap(5, 8, 10, 5, 22),
            25, class_3417.field_21866, 5.0F, 0.3F, class_6862.method_40092(
            class_7923.field_41178.method_46765(),
            class_2960.method_60655(Skulkmod.MOD_ID, "skulk_repair")
    ),
            NOTHING);
    public static final class_1741 SCULK_ANIMAL_ARMOR = new class_1741(60, createDefenseMap(0, 0, 0, 0, 22),
            25, class_3417.field_21866, 5.0F, 0.3F, class_6862.method_40092(
            class_7923.field_41178.method_46765(),
            class_2960.method_60655(Skulkmod.MOD_ID, "skulk_repair")
    ), NOTHING);
    static Map<class_8051, Integer> createDefenseMap(int bootsDefense, int leggingsDefense, int chestplateDefense, int helmetDefense, int bodyDefense) {
        return Maps.newEnumMap(Map.of(class_8051.field_41937, bootsDefense, class_8051.field_41936, leggingsDefense, class_8051.field_41935, chestplateDefense, class_8051.field_41934, helmetDefense, class_8051.field_48838, bodyDefense));
    }
}
