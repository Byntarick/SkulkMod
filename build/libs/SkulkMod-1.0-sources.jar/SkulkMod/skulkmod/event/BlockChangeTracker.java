package SkulkMod.skulkmod.event;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import java.util.*;
public class BlockChangeTracker {
    private static final Map<String, Map<class_2338, class_2680>> previousBlockStates = new HashMap<>();
    private static final Map<String, Map<class_2338, String>> pendingPlacements = new HashMap<>();
    private static int tickCounter = 0;
    public static void register() {
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, entity) -> {
            if (!world.method_8608()) {
                String playerName = player.method_5477().getString();
                String oldBlock = class_7923.field_41175.method_10221(state.method_26204()).toString();

                WorldBlockHistory.logAction(
                        (class_3218) world,
                        pos,
                        playerName,
                        "СЛОМАЛ",
                        oldBlock,
                        "minecraft:air"
                );
            }
            return true;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.method_8608() && hand == class_1268.field_5808) {
                class_2338 pos = hitResult.method_17777().method_10093(hitResult.method_17780());
                String worldKey = world.method_27983().method_29177().toString();

                pendingPlacements.computeIfAbsent(worldKey, k -> new HashMap<>())
                        .put(pos, player.method_5477().getString());
            }
            return class_1269.field_5811;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3218 world : server.method_3738()) {
                String worldKey = world.method_27983().method_29177().toString();


                Map<class_2338, String> pending = pendingPlacements.get(worldKey);
                if (pending != null && !pending.isEmpty()) {

                    Set<class_2338> keysToCheck = new HashSet<>(pending.keySet());

                    for (class_2338 pos : keysToCheck) {
                        String playerName = pending.get(pos);

                        if (world.method_8393(pos.method_10263() >> 4, pos.method_10260() >> 4)) {
                            class_2680 currentState = world.method_8320(pos);

                            if (!currentState.method_26215()) {
                                class_1657 player = server.method_3760().method_14566(playerName);
                                if (player != null) {
                                    WorldBlockHistory.logAction(
                                            world, pos, playerName, "ПОСТАВИЛ",
                                            "minecraft:air",
                                            class_7923.field_41175.method_10221(currentState.method_26204()).toString()
                                    );
                                }
                                pending.remove(pos);
                            }
                        }

                        if (world.method_75260() % 4000 == 0) {
                            pending.remove(pos);
                        }
                    }
                }
                Map<class_2338, class_2680> worldStates = previousBlockStates.get(worldKey);
                if (worldStates == null) {
                    worldStates = new HashMap<>();
                    previousBlockStates.put(worldKey, worldStates);
                }
                Set<class_2338> positionsToCheck = new HashSet<>(worldStates.keySet());

                for (class_2338 pos : positionsToCheck) {
                    class_2680 oldState = worldStates.get(pos);

                    if (world.method_8393(pos.method_10263() >> 4, pos.method_10260() >> 4)) {
                        class_2680 currentState = world.method_8320(pos);

                        if (currentState.method_26204() != oldState.method_26204()) {

                            if (!oldState.method_26215() && !currentState.method_26215()) {
                                class_1657 nearestPlayer = world.method_18459(pos.method_10263(), pos.method_10264(), pos.method_10260(), 5, false);
                                String playerName = nearestPlayer != null ? nearestPlayer.method_5477().getString() : "UNKNOWN";

                                WorldBlockHistory.logAction(
                                        world, pos, playerName, "ЗАМЕНИЛ",
                                        class_7923.field_41175.method_10221(oldState.method_26204()).toString(),
                                        class_7923.field_41175.method_10221(currentState.method_26204()).toString()
                                );
                            }
                            worldStates.put(pos.method_10062(), currentState);
                        }
                    } else {
                        worldStates.remove(pos);
                    }
                }
                for (class_2338 pos : WorldBlockHistory.getAllHistory(world).keySet()) {
                    if (!worldStates.containsKey(pos) && world.method_8393(pos.method_10263() >> 4, pos.method_10260() >> 4)) {
                        worldStates.put(pos, world.method_8320(pos));
                    }
                }
            }
            tickCounter++;
            if (tickCounter >= 6000) {
                WorldBlockHistory.saveAll(server);
                tickCounter = 0;
            }
        });
        ServerWorldEvents.UNLOAD.register((server, world) -> {
            String worldKey = world.method_27983().method_29177().toString();
            WorldBlockHistory.saveWorld(world);
            previousBlockStates.remove(worldKey);
            pendingPlacements.remove(worldKey);
        });
    }
}