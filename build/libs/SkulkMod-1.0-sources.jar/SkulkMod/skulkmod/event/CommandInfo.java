package SkulkMod.skulkmod.event;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Map;

import static net.minecraft.class_2170.*;
public class CommandInfo {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            register(dispatcher);
        });
    }
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("blockinfo")
                .then(method_9247("history")
                        .then(method_9244("x", IntegerArgumentType.integer())
                                .then(method_9244("y", IntegerArgumentType.integer())
                                        .then(method_9244("z", IntegerArgumentType.integer())
                                                .executes(context -> showHistory(
                                                        context,
                                                        IntegerArgumentType.getInteger(context, "x"),
                                                        IntegerArgumentType.getInteger(context, "y"),
                                                        IntegerArgumentType.getInteger(context, "z")
                                                ))
                                        )
                                )
                        )
                )
                .then(method_9247("stats")
                        .executes(CommandInfo::showStats)
                )
                .then(method_9247("save")
                        .executes(CommandInfo::forceSave)
                )
                .then(method_9247("worlds")
                        .executes(CommandInfo::showWorlds)
                )
        );
    }

    private static int showHistory(CommandContext<class_2168> context, int x, int y, int z) {
        class_3218 world = context.getSource().method_9225();
        class_2338 pos = new class_2338(x, y, z);
        List<BlockHistoryData.BlockAction> history = WorldBlockHistory.getHistory(world, pos);

        String saveName = world.method_8503().method_27728().method_150();
        String dimension = world.method_27983().method_29177().toString();

        if (history.isEmpty()) {
            context.getSource().method_9226(() ->
                            class_2561.method_43470("Нет записей для блока")
                                    .method_27692(class_124.field_1080),
                    false
            );
            context.getSource().method_9226(() ->
                            class_2561.method_43470("   Сохранение: " + saveName)
                                    .method_27692(class_124.field_1075),
                    false
            );
            context.getSource().method_9226(() ->
                            class_2561.method_43470("   Измерение: " + dimension)
                                    .method_27692(class_124.field_1075),
                    false
            );
            context.getSource().method_9226(() ->
                            class_2561.method_43470("   Координаты: " + x + " " + y + " " + z)
                                    .method_27692(class_124.field_1054),
                    false
            );
            return 0;
        }

        context.getSource().method_9226(() ->
                        class_2561.method_43470("═══════════════════════════════════════")
                                .method_27692(class_124.field_1065),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("ИСТОРИЯ БЛОКА")
                                .method_27695(class_124.field_1065, class_124.field_1067),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("   Сохранение: " + saveName)
                                .method_27692(class_124.field_1075),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("   Измерение: " + dimension)
                                .method_27692(class_124.field_1075),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("   Координаты: " + x + " " + y + " " + z)
                                .method_27692(class_124.field_1054),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("═══════════════════════════════════════")
                                .method_27692(class_124.field_1065),
                false
        );

        for (int i = 0; i < history.size(); i++) {
            BlockHistoryData.BlockAction action = history.get(i);
            final int displayIndex = i + 1;
            final BlockHistoryData.BlockAction finalAction = action;

            context.getSource().method_9226(() -> {
                class_2561 prefix = class_2561.method_43470(String.format("%2d. ", displayIndex)).method_27692(class_124.field_1063);
                class_2561 time = class_2561.method_43470("[" + finalAction.time + "] ").method_27692(class_124.field_1077);
                class_2561 player = class_2561.method_43470(finalAction.player).method_27692(class_124.field_1075);

                class_2561 actionText;
                if (finalAction.action.equals("СЛОМАЛ")) {
                    actionText = class_2561.method_43470(" СЛОМАЛ ").method_27692(class_124.field_1061);
                } else if (finalAction.action.equals("ПОСТАВИЛ")) {
                    actionText = class_2561.method_43470(" ПОСТАВИЛ ").method_27692(class_124.field_1060);
                } else {
                    actionText = class_2561.method_43470(" " + finalAction.action + " ").method_27692(class_124.field_1054);
                }

                class_2561 blocks = class_2561.method_43470(finalAction.oldBlock + " → " + finalAction.newBlock).method_27692(class_124.field_1068);

                return class_2561.method_43470("").method_10852(prefix).method_10852(time).method_10852(player).method_10852(actionText).method_10852(blocks);
            }, false);
        }

        context.getSource().method_9226(() ->
                        class_2561.method_43470("═══════════════════════════════════════")
                                .method_27692(class_124.field_1065),
                false
        );

        final int totalSize = history.size();
        context.getSource().method_9226(() ->
                        class_2561.method_43470("Всего записей: " + totalSize)
                                .method_27692(class_124.field_1080),
                false
        );

        return 1;
    }

    private static int showStats(CommandContext<class_2168> context) {
        class_3218 world = context.getSource().method_9225();
        Map<class_2338, List<BlockHistoryData.BlockAction>> allHistory = WorldBlockHistory.getAllHistory(world);

        int totalBlocks = allHistory.size();

        int actionCount = 0;
        for (List<BlockHistoryData.BlockAction> actions : allHistory.values()) {
            actionCount += actions.size();
        }
        final int totalActions = actionCount;

        class_2338 mostActive = null;
        int maxActions = 0;

        for (Map.Entry<class_2338, List<BlockHistoryData.BlockAction>> entry : allHistory.entrySet()) {
            int size = entry.getValue().size();
            if (size > maxActions) {
                maxActions = size;
                mostActive = entry.getKey();
            }
        }

        String saveName = world.method_8503().method_27728().method_150();
        String dimension = world.method_27983().method_29177().toString();

        context.getSource().method_9226(() ->
                        class_2561.method_43470("═══════════════════════════════════════")
                                .method_27692(class_124.field_1065),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("СТАТИСТИКА")
                                .method_27695(class_124.field_1065, class_124.field_1067),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("   Сохранение: " + saveName)
                                .method_27692(class_124.field_1075),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("   Измерение: " + dimension)
                                .method_27692(class_124.field_1075),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("═══════════════════════════════════════")
                                .method_27692(class_124.field_1065),
                false
        );

        final int finalTotalBlocks = totalBlocks;
        context.getSource().method_9226(() ->
                        class_2561.method_43470("Отслеживается блоков: " + finalTotalBlocks)
                                .method_27692(class_124.field_1068),
                false
        );

        context.getSource().method_9226(() ->
                        class_2561.method_43470("Всего действий: " + totalActions)
                                .method_27692(class_124.field_1068),
                false
        );

        if (mostActive != null) {
            class_2338 finalMostActive = mostActive;
            int finalMaxActions = maxActions;
            context.getSource().method_9226(() ->
                            class_2561.method_43470("Самый активный блок: ["
                                            + finalMostActive.method_10263() + " "
                                            + finalMostActive.method_10264() + " "
                                            + finalMostActive.method_10260() + "] ("
                                            + finalMaxActions + " действий)")
                                    .method_27692(class_124.field_1054),
                    false
            );
        }

        return 1;
    }

    private static int showWorlds(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        class_3218 currentWorld = source.method_9225();
        MinecraftServer server = source.method_9211();

        source.method_9226(() -> class_2561.method_43470("══════════════════════════════").method_27692(class_124.field_1065), false);
        source.method_9226(() -> class_2561.method_43470("СОХРАНЕНИЯ").method_27695(class_124.field_1065, class_124.field_1067), false);
        source.method_9226(() -> class_2561.method_43470("══════════════════════════════").method_27692(class_124.field_1065), false);

        // Просто показываем все миры на сервере
        for (class_3218 world : server.method_3738()) {
            String worldName = world.method_27983().method_29177().toString();
            class_2561 worldText = class_2561.method_43470("• " + worldName)
                    .method_27692(world == currentWorld ? class_124.field_1060 : class_124.field_1068);
            source.method_9226(() -> worldText, false);
        }

        source.method_9226(() -> class_2561.method_43470("══════════════════════════════").method_27692(class_124.field_1065), false);
        return 1;
    }
    private static int forceSave(CommandContext<class_2168> context) {
        WorldBlockHistory.saveAll(context.getSource().method_9211());

        context.getSource().method_9226(() ->
                        class_2561.method_43470("История всех миров принудительно сохранена")
                                .method_27692(class_124.field_1060),
                false
        );

        return 1;
    }
}