package SkulkMod.skulkmod.event;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_18;
import net.minecraft.class_2338;

public class BlockHistoryData extends class_18 {
    private final Map<class_2338, List<BlockAction>> blockHistory = new ConcurrentHashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private Path savePath;

    public BlockHistoryData(Path savePath) {
        this.savePath = savePath;
        loadFromFile();
    }

    public void saveToFile() {
        try {
            Files.createDirectories(savePath.getParent());

            List<SerializableAction> actions = new ArrayList<>();
            for (Map.Entry<class_2338, List<BlockAction>> entry : blockHistory.entrySet()) {
                class_2338 pos = entry.getKey();
                for (BlockAction action : entry.getValue()) {
                    actions.add(new SerializableAction(
                            pos.method_10263(), pos.method_10264(), pos.method_10260(),
                            action.player, action.action,
                            action.oldBlock, action.newBlock, action.time
                    ));
                }
            }

            String json = GSON.toJson(actions);
            Files.writeString(savePath, json);

        } catch (IOException e) {
            System.err.println("Ошибка сохранения: " + savePath);
            e.printStackTrace();
        }
    }

    public void loadFromFile() {
        try {
            if (!Files.exists(savePath)) {
                return;
            }

            String json = Files.readString(savePath);
            Type listType = new TypeToken<ArrayList<SerializableAction>>(){}.getType();
            List<SerializableAction> actions = GSON.fromJson(json, listType);

            blockHistory.clear();

            for (SerializableAction action : actions) {
                class_2338 pos = new class_2338(action.x, action.y, action.z);
                BlockAction ba = new BlockAction(
                        pos, action.player, action.action,
                        action.oldBlock, action.newBlock, action.time
                );
                blockHistory.computeIfAbsent(pos, k -> new ArrayList<>()).add(ba);
            }

        } catch (IOException e) {
            System.err.println("Ошибка загрузки: " + savePath);
            e.printStackTrace();
        }
    }

    public void addAction(class_2338 pos, String player, String action, String oldBlock, String newBlock, String time) {
        BlockAction ba = new BlockAction(pos, player, action, oldBlock, newBlock, time);
        blockHistory.computeIfAbsent(pos.method_10062(), k -> new ArrayList<>()).add(ba);
    }

    public List<BlockAction> getHistory(class_2338 pos) {
        return blockHistory.getOrDefault(pos, new ArrayList<>());
    }

    public Map<class_2338, List<BlockAction>> getAllHistory() {
        return blockHistory;
    }

    private static class SerializableAction {
        int x, y, z;
        String player, action, oldBlock, newBlock, time;

        SerializableAction(int x, int y, int z, String player, String action,
                           String oldBlock, String newBlock, String time) {
            this.x = x; this.y = y; this.z = z;
            this.player = player; this.action = action;
            this.oldBlock = oldBlock; this.newBlock = newBlock;
            this.time = time;
        }
    }

    public static class BlockAction {
        public final class_2338 pos;
        public final String player;
        public final String action;
        public final String oldBlock;
        public final String newBlock;
        public final String time;

        public BlockAction(class_2338 pos, String player, String action, String oldBlock, String newBlock, String time) {
            this.pos = pos;
            this.player = player;
            this.action = action;
            this.oldBlock = oldBlock;
            this.newBlock = newBlock;
            this.time = time;
        }
    }
}