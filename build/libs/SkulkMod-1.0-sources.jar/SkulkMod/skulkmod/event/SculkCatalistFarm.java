package SkulkMod.skulkmod.event;

import SkulkMod.skulkmod.item.ModItems;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import java.util.HashMap;
import java.util.Map;

public class SculkCatalistFarm {
    private static final Map<class_2338, Integer> catalystClicks = new HashMap<>();
    private static final class_1792[] ALL_SWORDS = new class_1792[]{
            class_1802.field_8091,
            class_1802.field_8528,
            class_1802.field_8371,
            class_1802.field_8845,
            class_1802.field_8802,
            class_1802.field_22022,
            ModItems.SCULK_SWORD
    };
    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608()) {
                return class_1269.field_5811;
            }
            class_2338 pos = hitResult.method_17777();
            if (!world.method_8320(pos).method_27852(class_2246.field_37570)) return class_1269.field_5811;
            System.out.println("qqqq");

            class_1799 stack = player.method_5998(hand);

            if (!isSword(stack)) return class_1269.field_5811;

            handleCatalystClick((class_3218) world, pos);

            return class_1269.field_5812;
        });
    }

    private static boolean isSword(class_1799 stack) {
        for (class_1792 sword : ALL_SWORDS) {
            if (stack.method_31574(sword)) return true;
        }
        return false;
    }

    private static void handleCatalystClick(class_3218 world, class_2338 pos) {
        System.out.println("wdwd");
        int clicks = catalystClicks.getOrDefault(pos, 0) + 1;

        if (clicks >= 5) {
            class_1542 drop = new class_1542(
                    world,
                    pos.method_10263() + 0.5,
                    pos.method_10264() + 1,
                    pos.method_10260() + 0.5,
                    new class_1799(class_1802.field_38746)
            );
            world.method_8649(drop);

            catalystClicks.remove(pos);
        } else {
            catalystClicks.put(pos, clicks);
        }
    }
}
