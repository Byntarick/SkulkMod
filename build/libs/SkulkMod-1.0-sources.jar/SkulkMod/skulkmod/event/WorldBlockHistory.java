package SkulkMod.skulkmod.event;

import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class WorldBlockHistory {
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final Map<String, BlockHistoryData> worldHistories = new ConcurrentHashMap<>();
    private static String getSaveFolderName(class_3218 world) {
        MinecraftServer server = world.method_8503();

        if (server.method_3816()) {
            return "server";
        } else {
            try {
                Path savesPath = Paths.get("saves");
                if (savesPath.toFile().exists()) {
                    File[] saveDirs = savesPath.toFile().listFiles(File::isDirectory);
                    if (saveDirs != null) {
                        for (File saveDir : saveDirs) {
                            Path levelDat = saveDir.toPath().resolve("level.dat");
                            if (levelDat.toFile().exists()) {
                                return saveDir.getName();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }


            return server.method_27728().method_150();
        }
    }

    private static String getWorldUniqueId(class_3218 world) {
        String saveFolder = getSaveFolderName(world);
        String dimension = world.method_27983().method_29177().toString().replace(':', '_');
        return saveFolder + "_" + dimension;
    }

    private static Path getWorldSavePath(class_3218 world) {
        String dimension = world.method_27983().method_29177().toString().replace(':', '_');

        if (world.method_8503().method_3816()) {
            return Paths.get("world/blockhistory/" + dimension + ".json");
        } else {
            String saveFolder = getSaveFolderName(world);
            return Paths.get("saves/" + saveFolder + "/blockhistory/" + dimension + ".json");
        }
    }

    public static BlockHistoryData getWorldData(class_3218 world) {
        String uniqueId = getWorldUniqueId(world);

        return worldHistories.computeIfAbsent(uniqueId, k -> {
            Path savePath = getWorldSavePath(world);
            System.out.println("📁 Загрузка истории для:");
            System.out.println("   ID: " + uniqueId);
            System.out.println("   Путь: " + savePath);

            BlockHistoryData data = new BlockHistoryData(savePath);
            return data;
        });
    }

    public static void logAction(class_3218 world, class_2338 pos, String playerName, String action, String oldBlock, String newBlock) {
        BlockHistoryData data = getWorldData(world);
        String time = LocalDateTime.now().format(TIME_FORMATTER);

        data.addAction(pos, playerName, action, oldBlock, newBlock, time);
        data.saveToFile(); // Сохраняем сразу
    }

    public static List<BlockHistoryData.BlockAction> getHistory(class_3218 world, class_2338 pos) {
        return getWorldData(world).getHistory(pos);
    }

    public static Map<class_2338, List<BlockHistoryData.BlockAction>> getAllHistory(class_3218 world) {
        return getWorldData(world).getAllHistory();
    }

    public static void saveWorld(class_3218 world) {
        String uniqueId = getWorldUniqueId(world);
        BlockHistoryData data = worldHistories.get(uniqueId);
        if (data != null) {
            data.saveToFile();
        }
    }

    public static void saveAll(MinecraftServer server) {
        for (class_3218 world : server.method_3738()) {
            saveWorld(world);
        }
    }
}


