package SkulkMod.skulkmod.event;
import SkulkMod.skulkmod.item.ModItems;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

@Environment(EnvType.CLIENT)
public class SculkRepairEvent {
    private static int time = 1;


    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            server.method_3760().method_14571().forEach(SculkRepairEvent::tickPlayer);
        });
    }

    private static void tickPlayer(class_1657 player) {
        time++;
       if(time % 5 == 0) {
           int count = 0;
        class_1937 world = player.method_73183();
        int R = 3;

        class_2338 center = player.method_24515();

        for (int x = -R; x <= R; x++) {
            for (int y = -R; y <= R; y++) {
                for (int z = -R; z <= R; z++) {
                    class_2338 pos = center.method_10069(x, y, z);
                    if (world.method_8320(pos).method_27852(class_2246.field_37568)) {
                        count++;
                    }
                }
            }
        }

        for (class_1304 slot : class_1304.values()) {
            class_1799 stack = player.method_6118(slot);
            if (!world.method_8608() && world instanceof class_3218 serverWorld) {
                if (!hasMending(serverWorld, stack)) continue;
                    if (stack.method_7960()) continue;
                if (stack.method_7963() && isSculk(stack)) {
                    int damage = stack.method_7919();
                    if (damage > 0) stack.method_7974(damage - (count/4));
                }
            }
        }
    }
    if (time == 6){
        time = 1;
    }

    }
    private static boolean isSculk(class_1799 stack){
        if (stack.method_31574(ModItems.SCULK_PICKAXE) || stack.method_31574(ModItems.SCULK_HOE) || stack.method_31574(ModItems.SCULK_AXE)|| stack.method_31574(ModItems.SCULK_SHOVEL)
                || stack.method_31574(ModItems.SCULK_SWORD) || stack.method_31574(ModItems.SCULK_BOOTS)|| stack.method_31574(ModItems.SCULK_CHESTPLATE)
                || stack.method_31574(ModItems.SCULK_HELMET) || stack.method_31574(ModItems.SCULK_LEGGINGS) || stack.method_31574(ModItems.SCULK_ELYTRA)
        ){
            return true;
        } else return false;
    }
    public static boolean hasMending(class_3218 world, class_1799 stack) {

        class_9304 enchants =
                stack.method_58694(class_9334.field_49633);

        if (enchants == null) return false;

        class_6880<?> mending = world
                .method_30349()
                .method_30530(class_7924.field_41265)
                .method_46747(class_1893.field_9101);

        return enchants.method_57534().contains(mending);
    }

}